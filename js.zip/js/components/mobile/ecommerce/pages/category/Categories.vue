<template>
    <div>
        <div class="bg-primary padding-x padding-bottom">
            <h3 class="title-page text-white">All Category</h3>
        </div>

        <section class="scroll-horizontal padding-around">
                <div class="item-sm">
                    <a href="#">
                        <div class="img-wrap">
                            <img class="rounded-circle img-sm" src="mobile/images/avatars/1.jpg" alt="">
                        </div>
                        <div class="text-wrap pt-2 text-center">
                            <p class="text-truncate">Men</p>
                        </div>
                    </a>
                </div>
                <div class="item-sm">
                    <a href="#">
                        <div class="img-wrap">
                            <img class="rounded-circle img-sm" src="mobile/images/avatars/2.jpg" alt="">
                        </div>
                        <div class="text-wrap pt-2 text-center">
                            <p class="text-truncate">Woman</p>
                        </div>
                    </a>
                </div>
                <div class="item-sm">
                    <a href="#">
                        <div class="img-wrap">
                            <img class="rounded-circle img-sm" src="mobile/images/avatars/3.jpg" alt="">
                        </div>
                        <div class="text-wrap pt-2 text-center">
                            <p class="text-truncate">Ladies</p>
                        </div>
                    </a>
                </div>
                <div class="item-sm">
                    <a href="#">
                        <div class="img-wrap">
                            <img class="rounded-circle img-sm" src="mobile/images/avatars/4.jpg" alt="">
                        </div>
                        <div class="text-wrap pt-2 text-center">
                            <p class="text-truncate">Baby</p>
                        </div>
                    </a>
                </div>

        </section> 


        <hr class="divider mb-3">


        <ul class="nav-menu">
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/cpu.svg" alt=""> </span>
                    <div class="text"> <h6 class="title">Devices</h6> <span class="text-muted">234 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/homeitem.svg" alt="">  </span>
                    <div class="text"> <h6 class="title">Equipments</h6> <span class="text-muted">354 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/book.svg" alt="">  </span>
                    <div class="text"> <h6 class="title">Books</h6> <span class="text-muted">48 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/ball.svg" alt="">  </span>
                    <div class="text"> <h6 class="title">Sports</h6> <span class="text-muted">97 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/cpu.svg" alt=""> </span>
                    <div class="text"> <h6 class="title">Electronics</h6> <span class="text-muted">234 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/homeitem.svg" alt="">  </span>
                    <div class="text"> <h6 class="title">Home items</h6> <span class="text-muted">354 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/book.svg" alt="">  </span>
                    <div class="text"> <h6 class="title">Books and magazines</h6> <span class="text-muted">48 items</span></div>
                </a>
            </li>
            <li class="nav-item">
                <a href="" class="icontext">
                    <span class="icon icon-sm bg-primary rounded"> <img src="mobile/images/icons/category-white/ball.svg" alt="">  </span>
                    <div class="text"> <h6 class="title">Sport and outdoor</h6> <span class="text-muted">97 items</span></div>
                </a>
            </li>
        </ul>
        <bottom-back-bottom></bottom-back-bottom>
    </div>
</template>