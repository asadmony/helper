<template>
    <div>
        <slider-section></slider-section>

        <service-project></service-project>

        <recently-viewed-products></recently-viewed-products>

        <best-sales></best-sales>

        <brand-section></brand-section>
    </div>
</template>
<script>
export default {
    
}
</script>
