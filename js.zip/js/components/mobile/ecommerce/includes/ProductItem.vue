<template>
    <div class="item">
        <a href="#" class="product-sm">
            <div class="img-wrap"> <img src="mobile/images/items/item.jpg"> </div>
            <div class="text-wrap">
                <p class="title text-truncate">Great item name</p>
                <div class="price">$27.00</div> <!-- price-wrap.// -->
            </div>
        </a>
    </div>
</template>