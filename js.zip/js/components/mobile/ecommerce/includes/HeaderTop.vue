<template>
    <div>
        <header class="app-header bg-primary">
            <button class="btn-header" type="button" data-trigger="#sidebar_left"><i class="fa fa-bars"></i></button>
            <!-- <h5 class="title-header ml-2">Ecommerce shop </h5> -->
            <div class="bg-primary">
                <input type="text" placeholder="Search" class="form-control input-dark border-0">
            </div>
            <div class="header-right">  
                <a href="#" class="btn-header"> <i class="fa fa-bell"></i> </a> 
            </div>
        </header> <!-- section-header.// -->
    </div>
</template>