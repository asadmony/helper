<template>
    <section class="mb-2 scroll-horizontal">
        <a href="#" class="item-slider card-banner">
            <div class="card-body bg-warning" style="height:220px; background-image: url('images/banners/slide1.jpg');"> </div>
            <div class="text-bottom"><h5 class="title">Super discount</h5></div>
        </a>
        <a href="#" class="item-slider card-banner">
            <div class="card-body bg-warning" style="height:220px; background-image: url('images/banners/slide2.jpg');"> </div>
            <div class="text-bottom"><h5 class="title">Get offers</h5></div>
        </a>
        <a href="#" class="item-slider card-banner">
            <div class="card-body bg-warning" style="height:220px; background-image: url('images/banners/slide3.jpg');"> </div>
            <div class="text-bottom"><h5 class="title">Best deals now</h5></div>
        </a>
    </section>
</template>